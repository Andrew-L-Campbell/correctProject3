-Andrew Campbell
-Readme for Project 2

For the bonus work I changed the class schedule to have alternating colors for each line.

I also embedded my body in a center float. 